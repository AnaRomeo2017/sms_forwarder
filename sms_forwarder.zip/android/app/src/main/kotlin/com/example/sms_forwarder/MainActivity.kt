package com.example.sms_forwarder

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
